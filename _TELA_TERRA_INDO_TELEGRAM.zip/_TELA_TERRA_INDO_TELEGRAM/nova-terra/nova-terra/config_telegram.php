<?php
// Configurações do Telegram Bot
// IMPORTANTE: Configure estas variáveis com os dados do seu bot

// Token do seu bot do Telegram
// Para obter: Fale com @BotFather no Telegram e crie um novo bot
$telegram_bot_token = "8594507908:AAHY0pQGcx2Qst2zmf2bEW3jN1rQWAH7QyI";

// ID do chat onde deseja receber as mensagens
// Para obter seu chat ID:
// 1. Envie uma mensagem para seu bot
// 2. Acesse: https://api.telegram.org/bot[SEU_TOKEN]/getUpdates
// 3. Procure pelo "chat":{"id":
$telegram_chat_id = "6514868118";

// Configurações opcionais
$telegram_enabled = true; // true para ativar, false para desativar
$telegram_timeout = 10; // timeout em segundos para requisições

?>